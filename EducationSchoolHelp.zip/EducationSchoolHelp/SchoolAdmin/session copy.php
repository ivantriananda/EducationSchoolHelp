<?php 
    session_start();
    $nama=$_SESSION['username'];
    $level=$_SESSION['level'];
    $id=$_SESSION['userID'];
    if ($level['level']=="admin") {
	    header("location:#");
    }
    else{
        header("location:../admin.php");
      }
?>